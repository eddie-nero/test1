Dropzone.autoDiscover = false;

var myDropzone = new Dropzone(".dropzone", {
    maxFilesize: 10,
    acceptedFiles: ".jpeg,.jpg,.png,.gif"
})